var config={
  jwtSecret:"JWTSECRET",
	miniProgram:{
		appId:"wxc3db312ddf9bcb01",
		appSecret:"6bb4f303f55a5893fac810e2ab56faa1"
	}
}

module.exports=config
